<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return [
	'title' => __( 'Countdown', 'elementor-pro' ),
	'required' => true,
	'default_activation' => true,
];
