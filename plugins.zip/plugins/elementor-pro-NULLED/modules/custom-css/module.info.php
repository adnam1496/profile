<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return [
	'title' => __( 'Custom CSS', 'elementor-pro' ),
	'required' => true,
	'default_activation' => true,
];
