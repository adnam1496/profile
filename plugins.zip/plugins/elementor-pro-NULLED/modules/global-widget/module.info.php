<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

return [
	'title' => __( 'Global Widget', 'elementor-pro' ),
	'required' => true,
	'default_activation' => true,
];
